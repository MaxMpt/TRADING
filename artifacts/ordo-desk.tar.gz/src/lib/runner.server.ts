import { study } from "@/lib/analyze";
import { agentLossesToday, DAILY_LOSS_CAP, decide, exitHit, type Side } from "@/lib/broker";
import { MOEX } from "@/lib/market";
import { loadQuoteList, loadSnapshot } from "@/lib/moex.functions";
import { placeClose, placeOpen, readBook } from "@/lib/trades.functions";

const NAMES = MOEX.map((item) => item.id);

type Look = { t: number; ticker: string; text: string };

function remember(ticker: string, text: string): void {
  const g = globalThis as typeof globalThis & { __ordoLooks?: Look[] };
  g.__ordoLooks = [{ t: Date.now(), ticker, text }, ...(g.__ordoLooks ?? [])].slice(0, 30);
}

type Streak = { side: Side | null; n: number };

const streaks = new Map<string, Streak>();
let cursor = 0;
let busy = false;

async function guardExits(): Promise<void> {
  const book = await readBook();
  if (!book.open.length) return;
  const quotes = await loadQuoteList(book.open.map((trade) => trade.ticker));
  for (const trade of book.open) {
    const quote = quotes.find((item) => item.ticker === trade.ticker);
    if (!quote) continue;
    const hit = exitHit(trade.side, trade.stop, trade.target, quote.bid, quote.ask, quote.last);
    if (!hit) continue;
    const price = trade.side === "long" ? quote.bid || quote.last : quote.ask || quote.last;
    if (!(price > 0)) continue;
    await placeClose({ id: trade.id, price, reason: hit });
  }
}

async function lookOne(): Promise<void> {
  const ticker = NAMES[cursor % NAMES.length] ?? NAMES[0];
  cursor += 1;
  if (!ticker) return;
  const book = await readBook();
  let snap;
  try {
    snap = await loadSnapshot(ticker, "5");
  } catch (error) {
    remember(ticker, error instanceof Error ? error.message : "биржа не ответила");
    console.error("[ordo]", ticker, error instanceof Error ? error.message : error);
    return;
  }
  const read = study(snap);
  const mine = book.open.find((trade) => trade.ticker === ticker) ?? null;
  const prev = streaks.get(ticker) ?? { side: null, n: 0 };
  const halted = agentLossesToday(book.closed) >= DAILY_LOSS_CAP;
  const decision = decide({
    inPosition: Boolean(mine),
    side: mine?.side ?? null,
    stop: mine?.stop ?? 0,
    target: mine?.target ?? 0,
    bid: snap.bid,
    ask: snap.ask,
    last: snap.last,
    agentOn: book.account.agentOn && !halted,
    session: snap.session,
    call: read.tradable ? read.call : "flat",
    score: read.score,
    bias: null,
    streakSide: prev.side,
    streakN: prev.n,
  });
  streaks.set(ticker, { side: decision.streakSide, n: decision.streakN });
  if (decision.intent.type === "close" && mine) {
    const price = mine.side === "long" ? snap.bid || snap.last : snap.ask || snap.last;
    if (price > 0) {
      await placeClose({ id: mine.id, price, reason: decision.intent.reason });
      remember(ticker, `закрыл ${decision.intent.reason === "target" ? "по тейку" : "по стопу"}`);
    }
    return;
  }
  if (decision.intent.type === "open") {
    const price = decision.intent.side === "long" ? snap.ask || snap.last : snap.bid || snap.last;
    if (!(price > 0)) return;
    try {
      await placeOpen({
        ticker,
        side: decision.intent.side,
        via: "agent",
        price,
        lot: snap.lot,
        stop: read.planStop,
      });
      remember(ticker, `открыл ${decision.intent.side === "long" ? "лонг" : "шорт"} от ${price.toFixed(2)}`);
      console.log(`[ordo] ${decision.intent.side} ${ticker} @ ${price}`);
    } catch (error) {
      remember(ticker, error instanceof Error ? error.message : "не открыл");
    }
    return;
  }
  const why = halted
    ? "четыре убытка за сегодня, новых входов нет"
    : !book.account.agentOn
      ? "агент выключен"
      : mine
        ? "позиция уже открыта"
        : read.block || read.note;
  remember(ticker, why);
}

async function pass(): Promise<void> {
  if (busy) return;
  busy = true;
  try {
    await guardExits();
    await lookOne();
  } catch (error) {
    console.error("[ordo]", error instanceof Error ? error.message : error);
  } finally {
    busy = false;
  }
}

type Slot = { stop: () => void };

export function startDeskRunner(): void {
  const g = globalThis as typeof globalThis & { __ordoRunner?: Slot };
  g.__ordoRunner?.stop();
  let dead = false;
  let timer: ReturnType<typeof setTimeout> | undefined;
  const loop = () => {
    if (dead) return;
    void pass().finally(() => {
      if (!dead) timer = setTimeout(loop, 8000);
    });
  };
  timer = setTimeout(loop, 1500);
  g.__ordoRunner = {
    stop() {
      dead = true;
      if (timer) clearTimeout(timer);
    },
  };
  console.log("[ordo] агент смотрит топ-30 акций Мосбиржи");
}
