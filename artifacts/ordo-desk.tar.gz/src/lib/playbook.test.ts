import assert from "node:assert/strict";
import test from "node:test";
import { findSetup, stageOf, withEntry, type Bar } from "./playbook.ts";

function rise(n: number, start: number, end: number): Bar[] {
  const out: Bar[] = [];
  for (let i = 0; i < n; i++) {
    const c = start + ((end - start) * i) / (n - 1);
    out.push({ h: c + 0.4, l: c - 0.4, c, v: 100 });
  }
  return out;
}

test("rising year qualifies as stage two", () => {
  const stage = stageOf(rise(260, 100, 220));
  assert.equal(stage.side, "long");
  assert.ok(stage.aboveLow >= 0.3);
  assert.ok(stage.offHigh <= 0.25);
});

test("false break of the high plans a short with a three-to-one target", () => {
  const daily = rise(40, 100, 110);
  const intra: Bar[] = [
    { h: 104, l: 101, c: 103 },
    { h: 107, l: 103, c: 104 },
    { h: 104, l: 101.5, c: 102.4 },
    { h: 103, l: 101, c: 102 },
  ];
  const played = findSetup({
    daily,
    intra,
    price: 102,
    levelHigh: 105,
    levelLow: 96,
    volRatio: 1,
  });
  assert.equal(played.stage.side, "flat");
  assert.equal(played.setup?.side, "short");
  assert.equal(played.setup?.model, "ложный пробой");
  const plan = played.setup ? withEntry("short", 102, played.setup.stop) : null;
  assert.ok(plan);
  if (plan) {
    const risk = plan.stop - 102;
    const reward = 102 - plan.target;
    assert.ok(Math.abs(reward / risk - 3) < 0.001);
  }
});

test("stop wider than eight percent is refused", () => {
  assert.equal(withEntry("long", 100, 90), null);
});
