import { createServerFn } from "@tanstack/react-start";
import { fetchCryptoQuotes, fetchCryptoSnapshot } from "@/lib/binance";
import { moexSession, nameOf, venueOf, type Candle, type Interval, type Quote, type Snapshot, type TapePrint } from "@/lib/market";

const ISS = "https://iss.moex.com/iss";

type CacheEntry = { at: number; candles: Candle[] };
const cache = new Map<string, CacheEntry>();

function allowed(ticker: string): boolean {
  return venueOf(ticker) !== null;
}

function num(value: unknown): number {
  const n = typeof value === "number" ? value : typeof value === "string" ? Number(value) : NaN;
  return Number.isFinite(n) ? n : 0;
}

function moexTime(value: unknown): number {
  if (typeof value !== "string" || !value) return 0;
  const ms = Date.parse(value.replace(" ", "T") + "+03:00");
  return Number.isFinite(ms) ? ms : 0;
}

function table(block: unknown): Record<string, unknown>[] {
  if (!block || typeof block !== "object") return [];
  const source = block as { columns?: unknown; data?: unknown };
  if (!Array.isArray(source.columns) || !Array.isArray(source.data)) return [];
  const columns = source.columns.map(String);
  return source.data.filter(Array.isArray).map((row) => {
    const record: Record<string, unknown> = {};
    columns.forEach((column, index) => {
      record[column] = (row as unknown[])[index];
    });
    return record;
  });
}

async function iss(path: string): Promise<unknown> {
  let last: unknown;
  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      const res = await fetch(`${ISS}${path}`, {
        headers: { Accept: "application/json", "User-Agent": "ordo" },
        signal: AbortSignal.timeout(8_000),
      });
      const text = await res.text();
      if (!res.ok || text.trim().startsWith("<")) throw new Error("Мосбиржа не ответила");
      return JSON.parse(text) as unknown;
    } catch (error) {
      last = error;
    }
  }
  throw last instanceof Error ? last : new Error("Мосбиржа не ответила");
}

function asCandles(payload: unknown): Candle[] {
  const root = payload as { candles?: unknown };
  return table(root.candles)
    .map((row) => ({
      t: moexTime(row.begin),
      o: num(row.open),
      h: num(row.high),
      l: num(row.low),
      c: num(row.close),
      v: num(row.volume),
    }))
    .filter((candle) => candle.t > 0 && candle.c > 0);
}

async function candles(ticker: string, interval: string, from: string, ttl = 60_000): Promise<Candle[]> {
  const key = `${ticker}:${interval}:${from}`;
  const hit = cache.get(key);
  if (hit && Date.now() - hit.at < ttl) return hit.candles;
  const all: Candle[] = [];
  for (let start = 0; start < 2000; start += 500) {
    const payload = await iss(
      `/engines/stock/markets/shares/boards/TQBR/securities/${ticker}/candles.json?interval=${interval}&from=${from}&start=${start}&iss.meta=off`,
    );
    const page = asCandles(payload);
    all.push(...page);
    if (page.length < 500) break;
  }
  cache.set(key, { at: Date.now(), candles: all });
  return all;
}

function foldFive(candles: Candle[]): Candle[] {
  const buckets = new Map<number, Candle>();
  for (const candle of candles) {
    const bucket = Math.floor(candle.t / 300_000) * 300_000;
    const prev = buckets.get(bucket);
    if (!prev) {
      buckets.set(bucket, { ...candle, t: bucket });
      continue;
    }
    prev.h = Math.max(prev.h, candle.h);
    prev.l = Math.min(prev.l, candle.l);
    prev.c = candle.c;
    prev.v += candle.v;
  }
  return [...buckets.values()].sort((a, b) => a.t - b.t);
}

function dayStamp(offset: number): string {
  const date = new Date(Date.now() - offset * 86_400_000);
  return date.toISOString().slice(0, 10);
}

function soon<T>(promise: Promise<T>, ms: number): Promise<T | null> {
  return new Promise((resolve) => {
    const timer = setTimeout(() => resolve(null), ms);
    promise.then(
      (value) => {
        clearTimeout(timer);
        resolve(value);
      },
      () => {
        clearTimeout(timer);
        resolve(null);
      },
    );
  });
}

function quoteFrom(ticker: string, payload: unknown): Quote {
  const root = payload as { securities?: unknown; marketdata?: unknown };
  const sec = table(root.securities)[0] ?? {};
  const md = table(root.marketdata)[0] ?? {};
  const last = num(md.LAST) || num(sec.PREVPRICE);
  const prev = num(sec.PREVPRICE) || last;
  const bid = num(md.BID);
  const ask = num(md.OFFER);
  const session = moexSession() && bid > 0 && ask > 0;
  return {
    ticker,
    name: typeof sec.SHORTNAME === "string" ? sec.SHORTNAME : nameOf(ticker),
    last,
    prev,
    bid,
    ask,
    changePct: prev > 0 ? ((last - prev) / prev) * 100 : 0,
    lot: Math.max(1, num(sec.LOTSIZE) || 1),
    decimals: Math.max(0, num(sec.DECIMALS) || 1),
    valueToday: num(md.VALTODAY),
    session,
    unit: "₽",
  };
}

type SnapHit = { at: number; snap: Snapshot };
const snaps = new Map<string, SnapHit>();
const inflight = new Map<string, Promise<Snapshot>>();

async function fetchSnapshot(ticker: string, interval: Interval): Promise<Snapshot> {
  const chartPromise =
    interval === "5"
      ? candles(ticker, "10", dayStamp(3), 20_000)
      : candles(ticker, interval, interval === "24" ? dayStamp(400) : dayStamp(12), 60_000);
  const [board, trades, chart, daily] = await Promise.all([
    iss(`/engines/stock/markets/shares/boards/TQBR/securities/${ticker}.json?iss.meta=off`),
    soon(
      iss(`/engines/stock/markets/shares/boards/TQBR/securities/${ticker}/trades.json?iss.meta=off`),
      3_000,
    ),
    chartPromise,
    candles(ticker, "24", dayStamp(400), 15 * 60_000),
  ]);
  const quote = quoteFrom(ticker, board);
  const prints = trades
    ? table((trades as { trades?: unknown }).trades)
        .map((row) => ({
          id: num(row.TRADENO),
          price: num(row.PRICE),
          qty: num(row.QUANTITY),
          time: moexTime(`${row.TRADEDATE ?? ""} ${row.TRADETIME ?? ""}`.trim()),
          sell: row.BUYSELL === "S",
        }))
        .filter((print) => print.price > 0 && print.qty > 0)
        .sort((a, b) => a.time - b.time)
    : [];
  const tape: TapePrint[] = prints.slice(-40);
  const market = table((board as { marketdata?: unknown }).marketdata)[0];
  const bids = quote.bid > 0 ? [{ price: quote.bid, qty: num(market?.BIDDEPTH) }] : [];
  const asks = quote.ask > 0 ? [{ price: quote.ask, qty: num(market?.OFFERDEPTH) }] : [];
  return { ...quote, interval, candles: chart, daily, bids, asks, tape };
}

function loadFresh(ticker: string, interval: Interval): Promise<Snapshot> {
  const key = `${ticker}:${interval}`;
  const pending = inflight.get(key);
  if (pending) return pending;
  const job = fetchSnapshot(ticker, interval)
    .then((snap) => {
      snaps.set(key, { at: Date.now(), snap });
      return snap;
    })
    .finally(() => {
      if (inflight.get(key) === job) inflight.delete(key);
    });
  inflight.set(key, job);
  return job;
}

export async function loadSnapshot(ticker: string, interval: Interval): Promise<Snapshot> {
  if (venueOf(ticker) === "crypto") return fetchCryptoSnapshot(ticker, interval);
  const key = `${ticker}:${interval}`;
  const hit = snaps.get(key);
  const age = hit ? Date.now() - hit.at : Infinity;
  if (hit && age < 4_000) return hit.snap;
  if (hit && age < 5 * 60_000) {
    void loadFresh(ticker, interval).catch(() => {
      /* stale snapshot stays on screen; the next poll tries again */
    });
    return hit.snap;
  }
  return loadFresh(ticker, interval);
}

export async function loadQuoteList(tickers: string[]): Promise<Quote[]> {
  const clean = tickers.filter((ticker) => allowed(ticker)).slice(0, 24);
  const crypto = clean.filter((ticker) => venueOf(ticker) === "crypto");
  const shares = clean.filter((ticker) => venueOf(ticker) === "moex");
  const [cryptoQuotes, boards] = await Promise.all([
    crypto.length ? fetchCryptoQuotes(crypto) : Promise.resolve([] as Quote[]),
    Promise.all(
      shares.map((ticker) =>
        iss(`/engines/stock/markets/shares/boards/TQBR/securities/${ticker}.json?iss.meta=off&iss.only=securities,marketdata`),
      ),
    ),
  ]);
  return [...cryptoQuotes, ...shares.map((ticker, index) => quoteFrom(ticker, boards[index]))];
}

export const loadMarket = createServerFn({ method: "POST" })
  .validator((input: unknown) => {
    const source = input as { ticker?: unknown; interval?: unknown };
    const ticker = typeof source.ticker === "string" ? source.ticker : "";
    const interval = source.interval === "5" || source.interval === "60" || source.interval === "24" ? source.interval : "5";
    if (!allowed(ticker)) throw new Error("Неизвестный тикер");
    return { ticker, interval: interval as Interval };
  })
  .handler(async ({ data }): Promise<Snapshot> => loadSnapshot(data.ticker, data.interval));

export const loadQuotes = createServerFn({ method: "POST" })
  .validator((input: unknown) => {
    const tickers = (input as { tickers?: unknown }).tickers;
    if (!Array.isArray(tickers)) return { tickers: [] as string[] };
    const clean = tickers.filter((ticker): ticker is string => typeof ticker === "string" && allowed(ticker)).slice(0, 8);
    return { tickers: clean };
  })
  .handler(async ({ data }): Promise<Quote[]> => loadQuoteList(data.tickers));

export type LookRow = { t: number; ticker: string; text: string };

export const loadLooks = createServerFn({ method: "GET" }).handler(async (): Promise<LookRow[]> => {
  const rows = (globalThis as typeof globalThis & { __ordoLooks?: LookRow[] }).__ordoLooks ?? [];
  return rows.slice(0, 12);
});
